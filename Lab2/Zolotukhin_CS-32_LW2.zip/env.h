#ifndef _ENV_H_
#define _ENV_H_

void env_info();
void get_info(char* str);
void set_value(char* str);
void put(char* var,char* val);
void del(char* str);
void clear();
void help();

#endif