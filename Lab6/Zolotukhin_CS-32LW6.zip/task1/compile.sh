remove a.out
clear
gcc main.c -lpthread
./a.out 10