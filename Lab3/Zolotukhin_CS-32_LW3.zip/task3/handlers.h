//auto gen start
void handler1(void);
void handler2(void);
void handler3(void);
void handler4(void);
void handler5(void);
void handler6(void);
void handler7(void);
void handler8(void);
void handler9(void);
void handler10(void);
void handler11(void);
void handler12(void);
void handler13(void);
void handler14(void);
void handler15(void);
void handler16(void);
void handler17(void);
void handler18(void);
void handler19(void);
void handler20(void);
void handler21(void);
void handler22(void);
void handler23(void);
void handler24(void);
void handler25(void);
void handler26(void);
void handler27(void);
void handler28(void);
void handler29(void);
void handler30(void);
void handler31(void);
void handler32(void);
//auto gen end

void (*handler_arr[32])(void)=
{
	handler1,handler2,handler3,handler4,handler5,handler6,handler7,handler8,
	handler9,handler10,handler11,handler12,handler13,handler14,handler15,handler16,
	handler17,handler18,handler19,handler20,handler21,handler22,handler23,handler24,
	handler25,handler26,handler27,handler28,handler29,handler30,handler31,handler32
};