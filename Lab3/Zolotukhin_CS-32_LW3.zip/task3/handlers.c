#include <stdlib.h>
#include <stdio.h>
//auto gen start
void handler1(void)
{
	sleep(1);
	printf("handler1\n");
}

void handler2(void)
{
	sleep(1);
	printf("handler2\n");
}

void handler3(void)
{
	sleep(1);
	printf("handler3\n");
}

void handler4(void)
{
	sleep(1);
	printf("handler4\n");
}

void handler5(void)
{
	sleep(1);
	printf("handler5\n");
}

void handler6(void)
{
	sleep(1);
	printf("handler6\n");
}

void handler7(void)
{
	sleep(1);
	printf("handler7\n");
}

void handler8(void)
{
	sleep(1);
	printf("handler8\n");
}

void handler9(void)
{
	sleep(1);
	printf("handler9\n");
}

void handler10(void)
{
	sleep(1);
	printf("handler10\n");
}

void handler11(void)
{
	sleep(1);
	printf("handler11\n");
}

void handler12(void)
{
	sleep(1);
	printf("handler12\n");
}

void handler13(void)
{
	sleep(1);
	printf("handler13\n");
}

void handler14(void)
{
	sleep(1);
	printf("handler14\n");
}

void handler15(void)
{
	sleep(1);
	printf("handler15\n");
}

void handler16(void)
{
	sleep(1);
	printf("handler16\n");
}

void handler17(void)
{
	sleep(1);
	printf("handler17\n");
}

void handler18(void)
{
	sleep(1);
	printf("handler18\n");
}

void handler19(void)
{
	sleep(1);
	printf("handler19\n");
}

void handler20(void)
{
	sleep(1);
	printf("handler20\n");
}

void handler21(void)
{
	sleep(1);
	printf("handler21\n");
}

void handler22(void)
{
	sleep(1);
	printf("handler22\n");
}

void handler23(void)
{
	sleep(1);
	printf("handler23\n");
}

void handler24(void)
{
	sleep(1);
	printf("handler24\n");
}

void handler25(void)
{
	sleep(1);
	printf("handler25\n");
}

void handler26(void)
{
	sleep(1);
	printf("handler26\n");
}

void handler27(void)
{
	sleep(1);
	printf("handler27\n");
}

void handler28(void)
{
	sleep(1);
	printf("handler28\n");
}

void handler29(void)
{
	sleep(1);
	printf("handler29\n");
}

void handler30(void)
{
	sleep(1);
	printf("handler30\n");
}

void handler31(void)
{
	sleep(1);
	printf("handler31\n");
}

void handler32(void)
{
	sleep(1);
	printf("handler32\n");
}

//auto gen end